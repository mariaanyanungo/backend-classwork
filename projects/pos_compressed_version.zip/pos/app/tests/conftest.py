import os
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

os.environ["DATABASE_URL"] = "sqlite://"

from database import Base, get_db
from main import app

engine = create_engine(
    "sqlite://", 
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)

TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture
def client():
    Base.metadata.create_all(bind=engine)
    
    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()
          
    app.dependency_overrides[get_db] = override_get_db
    
    yield TestClient(app)
    
    app.dependency_overrides.clear()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def test_user(client):
    test_user_data = {
        "username": "testuser",
        "email": "testuser@gmail.com",
        "password": "testpassword",
    }
    client.post("/auth/register", json=test_user_data)
    return test_user_data


@pytest.fixture
def auth_headers(client, test_user):
    response = client.post(
        "/auth/login", 
        data={
            "username": test_user["username"],
            "password": test_user["password"]
        }
    )
    access_token = response.json()["access_token"]
    return {"Authorization": f"Bearer {access_token}"}
