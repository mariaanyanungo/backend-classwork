from fastapi.testclient import TestClient
from app.core.security import hash_password, verify_password

def test_hash_password():
    password="testpassword"
    hashed_password=hash_password(password)
    assert isinstance(hashed_password,str)
    assert hash_password!=password
    
def test_verify_password():
    password="testpassword"
    hashed_password=hash_password(password)
    assert verify_password(password, hashed_password)
    assert not verify_password(password("test_password1", hashed_password))