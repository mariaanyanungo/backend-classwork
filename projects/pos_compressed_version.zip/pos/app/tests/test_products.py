# from fastapi.testclient import TestClient
# from main import app

# client=TestClient(app)

def test_list_products():
    response=client.get("/products")
    assert response.status_code==200
    
def test_create_product():
    product_data={
        "name":"Cocacola",
        "brand":"Coco",
        "category":"beverages"
    }
    response=client.post("/products",json=product_data, headers=auth_headers)
    assert response.status_code==201

def test_update_product(client, auth_headers):
    
    product_data={
          "name":"Cocacola",
         "brand":"Coco",
        "category":"beverages"
    }
    response=client.post("/products",json=product_data, headers=auth_headers)
    product_id=response.json()["id"]
    
    updated_product={
         "name":"Coco",
                 "brand":"Cocacola",
                "category":"beverages"
    }
    response=client.post(f"/products/{product_id}",json=updated_product, headers=auth_headers)
    assert response.json()["name"]=="Fanta"
    
    
    
    
def test_delete_product(client, auth_headers):
    
    product_data={
          "name":"Cocacola",
         "brand":"Coco",
        "category":"beverages"
    }
    response=client.post("/products",json=product_data, headers=auth_headers)
    product_id=response.json()["id"]
    
    product_data={
         "name":"Coco",
                 "brand":"Cocacola",
                "category":"beverages"
    }
    response=client.post(f"/products/{product_id}", headers=auth_headers)
   
def test_create_product_without_name_return_422(client, auth_headers):
        product_data={
                "brand":"Coco",
               "category":"beverages"
           }
       
        response=client.post(f"/products/{product_id}",json=product_data, headers=auth_headers)
        assert response.status_code==422
        
def test_get_noneextistent_product(client, auth_headers):
    response=client.get("/products/10000", headers=auth_headers)
    assert response.status_code==404
    
    
def test_create_product_without_login_returns_401():
    product_data={
             "name":"Coco",
                     "brand":"Cocacola",
                    "category":"beverages"
        }
    response= client.post("/products", json=product_data)
    assert response.status_code==401